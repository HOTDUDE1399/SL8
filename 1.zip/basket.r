library("arules")
library("arulesViz")

Groceries <- read.csv("groceries.csv")
data("Groceries")
itemFrequencyPlot(Groceries,topN=20,type='absolute')

rules<-apriori(data=Groceries, parameter=list(supp=0.001,conf = 0.15,minlen=2),
               appearance = list(default="rhs",lhs="whole milk"),  
               control = list(verbose=F))
rules <- rules[!is.redundant(rules)]
rules<-sort(rules, decreasing=TRUE,by="confidence")
options(digits = 3)
inspect(rules[1:5])

plot(rules,method="graph",interactive=TRUE,shading=NA) 
