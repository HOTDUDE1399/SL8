package codenew;

import java.math.BigInteger;
import java.util.Scanner;

public class RSA
{
	static BigInteger num1,num2;
	public int GCD(int a,int b)
	{
		if(b==0)
			return a;
		else 
			return GCD(b,a%b);
	}
	
	public int getPublic_Key(BigInteger phi)
	{
		int i=2;
		String btol1 = num1.toString();
		String btol2 = num2.toString();

		String btol3 = phi.toString();
		int phi1 = Integer.parseInt(btol3);
		
	    long no1  = Long.parseLong(btol1);
	    long no2  = Long.parseLong(btol2);

		while(GCD(i,phi1)!=1 ||no1==i || no2==i)
		{
			i++;
		}
		return i;
	}
	
	public int getPrivate_Key(int e,BigInteger phi)
	{
		int i=1;
		String btol = phi.toString();
	    long phi1  = Long.parseLong(btol);
		while(i<phi1 && ((i*e)%phi1)!=1)
		{
			i++;
		}
		return i;
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the first prime number:");
		num1 = sc.nextBigInteger();
		System.out.println("Enter the second prime number:");
		num2 = sc.nextBigInteger();
		System.out.println("Enter the message:");
		int m = sc.nextInt();
		BigInteger product = num1.multiply(num2);
		BigInteger phi = (num1.subtract(BigInteger.ONE)).multiply((num2.subtract(BigInteger.ONE)));
		RSA rsa = new RSA();
		int e = rsa.getPublic_Key(phi);
//		int e=13;
		int d = rsa.getPrivate_Key(e,phi);
		
		System.out.println("The Public key (e,n) is: ("+e+","+product+")");
		System.out.println("The Private key (d,n) is: ("+d+","+product+")");

		BigInteger big1 = BigInteger.valueOf(m).pow(e);
		
	    String btol = product.toString();
	    long prod  = Long.parseLong(btol);
	    
		BigInteger cipher = big1.mod(product);
		System.out.println("The ciphertext is :"+cipher);
		
		String btolcip = cipher.toString();
	    long ciphermain  = Long.parseLong(btolcip);
		
		BigInteger big2 = BigInteger.valueOf(ciphermain).pow(d);
		
		BigInteger  plain = big2.mod(product);
		System.out.println("The plain text is :"+plain);
	}
}