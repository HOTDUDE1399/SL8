import java.util.*;

class Chinese
{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter no of linear congruences");
		int n = sc.nextInt();
		int rem[] = new int[n];
		int inv[] = new int[n];
		//int m[] = new int[n];
		int num[] = new int[n];
		int M=1,i=0;
		while(i<n){
		System.out.println("Enter "+ i +"th remainder:");
		rem[i] = sc.nextInt();

		System.out.println("Enter "+ i +"th remainder:");
		num[i] = sc.nextInt();
		M = M*num[i];
		i++;
		}
		
		long total=0;

		for(int j=0;j<n;j++)
		{
			 int m =M/num[j];
			 System.out.println("m :"+m);
			i=0;
			int flag=0;
			while(i<num[j] && flag!=1)
			{
				//System.out.println("rem["+j+"]:"+rem[j]);
				//System.out.println("num["+j+"]:"+num[j]);
				if((i*m)%num[j]==1)
				{
					System.out.println("inv["+j+"]:"+i);
					inv[j] = i;
					flag=1;
				}
				i++;
			}


			total = total + rem[j]*m*inv[j];
			//System.out.println("Total :"+total);
			System.out.println("");

		}
		System.out.println("Final Total :"+total);
		System.out.println("M :"+M);
		long remainder = total % M;
		System.out.println("Remainder is :" +remainder);
	}

}

/*
OUTPUT:



Viveks-MacBook-Air:Desktop vivekpatil$ javac Chinese.java
Viveks-MacBook-Air:Desktop vivekpatil$ java Chinese
Enter no of linear congruences
3
Enter 0th remainder:
2
Enter 0th remainder:
7
Enter 1th remainder:
2
Enter 1th remainder:
7
Enter 2th remainder:
3
Enter 2th remainder:
9
m :63

m :63

m :49
inv[2]:7

Final Total :1029
M :441
Remainder is :147
Viveks-MacBook-Air:Desktop vivekpatil$ 

*/