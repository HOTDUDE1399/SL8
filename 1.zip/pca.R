library(arules)
library(arulesViz)

x=read.csv(file.csv)
x<-x[2:5]

attach(x)
names(x)
summary(x)

pca<-princomp(x,score=TRUE,cor=TRUE)

summary(pca)
loadings(pca)
plot(pca)
screeplot(pca,type=line,main="Scrren Plot1")
biplot(pca)
pca$scores[1:10]

